

var n = prompt('Введите длинну массива: ')

let arr = Array.from({ length: n }, () => Math.floor(Math.random() * 3));

console.log(arr)
let preitem = arr[0]
let streack = 0;
let streackcolor;

arr.slice(1).forEach((item) => {
    if (item === preitem) {
        streack++
        if (item === 0) {
            streackcolor = 0
        }
        if (item === 1) {
            streackcolor = 1
        }
        if (item === 2) {
            streackcolor = 2
        }
    }
    if (item != preitem) {
        streack = 0
        totalcolor = streackcolor;
    }
})


switch (totalcolor) {
    case 0:
        alert('Самая маленькая последовательность из красных шариков')
        break;
    case 1:
        alert('Самая маленькая последовательность из белых шариков')
        break;
    case 2:
        alert('Самая маленькая последовательность из черных  шариков')
        break;
}
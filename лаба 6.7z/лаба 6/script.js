function methodichka() {
    // const arr1 = [1, 2, 3];
    // const arr2 = [];
    // for (let i = 0; i < arr1.length; i++) {
    //     arr2.push(arr1[i] * 2);
    // }
    // выводит [ 2, 4, 6 ]
    // console.log(arr2);


    const arr1 = [1, 2, 3];
    const arr2 = arr1.map(function (item) {
        return item * 2;
    });
    console.log(arr2);

    const persons = [
        { name: 'Peter', age: 16 },
        { name: 'Mark', age: 18 },
        { name: 'John', age: 27 },
        { name: 'Jane', age: 14 },
        { name: 'Tony', age: 24 },
    ];
    const fullAge = persons.filter(person => person.age >= 18);
    console.log(fullAge);


}
function dopzap() {
    var n = prompt('Введите длинну массива: ')

    let arr = Array.from({ length: n }, () => Math.floor(Math.random() * 3));

    console.log(arr)
    let preitem = arr[0]
    let streack = 0;
    let streackcolor;

    arr.slice(1).forEach((item) => {
        if (item === preitem) {
            streack++
            if (item === 0) {
                streackcolor = 0
            }
            if (item === 1) {
                streackcolor = 1
            }
            if (item === 2) {
                streackcolor = 2
            }
        }
        if (item != preitem) {
            streack = 0
            totalcolor = streackcolor;
        }
    })


    switch (totalcolor) {
        case 0:
            alert('Самая маленькая последовательность из красных шариков')
            break;
        case 1:
            alert('Самая маленькая последовательность из белых шариков')
            break;
        case 2:
            alert('Самая маленькая последовательность из черных  шариков')
            break;
    }
}
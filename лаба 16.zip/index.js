const express = require('express')
const bodyParser = require('body-parser')

const app = express()

app.use(express.static('public'))

const urlencodedParser = bodyParser.urlencoded({
    extended: false,
})

//Обработка GET запросов
app.get('/', urlencodedParser, (req, res) => {
    console.log(req, res)
    res.sendFile(__dirname + '/index.html')
})

// Обратока POST запросов
app.post('/', urlencodedParser, (req, res) => {
    if (!req.body) return res.sendStatus(400);
    console.log(req.body);
    res.send(`${req.body.userName} - ${req.body.userAge}`)
})

// Обработка ошибки 404
app.get('*', urlencodedParser, (req, res) => {
    res.sendFile(__dirname + '/error.html')
})

// Запуск сервера
const PORT = 3000
app.listen(PORT, () => {
    console.log('Сервер запущен')
})
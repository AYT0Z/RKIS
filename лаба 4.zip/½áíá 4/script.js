function showMessage() {
    let message = "Привет, я JavaScript!"; // локальная переменная

    alert(message);
}

function getRandomInt(max) {
    return Math.floor(Math.random() * max);
}
// showMessage(); // Привет, я JavaScript!

// alert(message) // оно не работает тк переменная message в функции локальная

function polindr() {
    var lastname = prompt('Введите вашу фамилию').toLowerCase()
    var antilastname = lastname.split("").reverse().join("")
    // console.log(antilastname)
    if (lastname == antilastname) {
        alert('Фамилия палиндром')
    } else {
        alert('Фамилия не палиндром')
    }


}

function ArrayAntiMinus() {
    var Array = []
    var n = parseInt(prompt('Введите длинну массива'))
    for (let i = 0; i < n; i++) {

        Array[i] = parseInt(prompt("Введите " + (i + 1) + " элемент массива"))

    }
    alert('Первоначальный массив: ' + Array)
    console.log(Array)
    for (let i = 0; i < n; i++) {
        if (Array[i] < 0) Array[i] = Array[i] ** 2
    }
    console.log(Array)
    alert('Измененный массив: ' + Array)
}

// polindr()

// ArrayAntiMinus()

class User {
    constructor(name) {
        this.name = name
    }
    sayHi() {
        alert(this.name)
    }
}
let user = new User('Иван')
// user.sayHi()

class userName {
    constructor(name) {
        this.name = name
    }
    message() {
        alert('Привет,' + this.name)
    }
}
let vasya = new userName('Вася');

// vasya.message()


class Namereverse {
    constructor(name) {
        this.name = name
    }
    revers() {
        let revStr = this.name.split('').reverse().join('');
        alert(revStr)
    }
}

let secondUser = new Namereverse('Петя')

secondUser.revers()

class simulator {
    constructor() {
        this.redsec = 0;
        this.whitesec = 0;
        this.blacksec = 0;
    }
    spawnAndCheck(n) {
        var Array = []
        var currNum = getRandomInt(3)
        var redmax = 0;
        var whitemax = 0;
        var blackmax = 0
        var currplus = 0;
        for (let i = 0; i < n; i++) {
            currNum = getRandomInt(3)
            Array[i] = currNum

        }
        console.log(Array)
        for (let i = 0; i < n; i++) {
            if (Array[i] === 0) {
                redmax++
            } else {
                if (redmax > this.redsec) {
                    this.redsec = redmax
                }
                redmax = 0
            }

            if (Array[i] === 1) {
                blackmax++
            } else {
                if (blackmax > this.blacksec) {
                    this.blacksec = blackmax
                }
                blackmax = 0
            }

            if (Array[i] === 2) {
                whitemax++
            } else {
                if (whitemax > this.whitesec) {
                    this.whitesec = whitemax
                }
                whitemax = 0
            }

        }
        if (this.redsec > this.whitesec && this.redsec > this.blacksec) {
            alert('Наибольшая последовательность состоит из красных шариков: ' + this.redsec)
        } else if (this.whitesec > this.blacksec) {
            alert('Наибольшая последовательность состоит из белых шариков: ' + this.whitesec)
        } else alert('Наибольшая последовательность состоит из черных шариков: ' + this.blacksec)

    }
}

let sim = new simulator();

sim.spawnAndCheck(1000000)
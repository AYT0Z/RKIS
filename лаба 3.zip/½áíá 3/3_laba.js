function ArrayAVG() {
    var Array = []
    var ArrSum = 0
    for (let i = 0; i < 15; i++) {

        Array[i] = getRandomInt(-10, 15)
        // console.log(Array[i])
    }
    alert('Первоначальный массив: ' + Array)
    for (let i = 0; i < 15; i++) {
        ArrSum = ArrSum + Array[i]
    }
    ArrSum = ArrSum / 15
    // console.log(ArrSum)
    alert('Среднее среди элементов массива: ' + ArrSum)
}
function getRandomInt(min, max) {
    min = Math.ceil(min);
    max = Math.floor(max);
    return Math.floor(Math.random() * (max - min + 1)) + min;
}
function ArrayAntiMinus() {
    var Array = []
    var n = parseInt(prompt('Введите длинну массива'))
    for (let i = 0; i < n; i++) {

        Array[i] = parseInt(prompt("Введите " + (i + 1) + " элемент массива"))

    }
    alert('Первоначальный массив: ' + Array)
    console.log(Array)
    for (let i = 0; i < n; i++) {
        if (Array[i] < 0) Array[i] = Array[i] ** 2
    }
    console.log(Array)
    alert('Измененный массив: ' + Array)
}
function UberAVG() {
    var Array = []
    var n = parseInt(prompt('Введите длинну массива'))
    var MinusAVG = 0
    var PlusAVG = 0
    var Nulls = 0
    var MinusScore = 0
    var PlusScore = 0
    for (let i = 0; i < n; i++) {

        Array[i] = parseInt(prompt("Введите " + (i + 1) + " элемент массива"))

    }
    alert('Первоначальный массив: ' + Array)
    console.log(Array)
    for (let i = 0; i < n; i++) {
        if (Array[i] < 0) {
            MinusAVG = MinusAVG + Array[i]
            MinusScore++
        }
        if (Array[i] > 0) {
            PlusAVG = PlusAVG + Array[i]
            PlusScore++
        }
        if (Array[i] == 0) Nulls++

    }
    console.log(MinusAVG / MinusScore)
    console.log(PlusAVG / PlusScore)
    console.log(Nulls)
    alert('Среднее арифметическое отрицательных: ' + (MinusAVG / MinusScore))
    alert('Среднее арифметическое положительных: ' + (PlusAVG / PlusScore))
    alert('Кол-во нулей: ' + (Nulls))
}
function simulation() {
    // var Array = []
    var n = 1000000
    var currentColor
    var red = 0

    for (let i = 0; i < n; i++) {
        currentColor = getRandomInt(0, 2)
        if (currentColor == 0) red++
    }
    alert("Красный выпал " + red + " Раз")
}